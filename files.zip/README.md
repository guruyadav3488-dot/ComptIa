# Deep Learning Projects

A collection of small deep learning projects (CNNs, RNNs, and LSTMs) built with
TensorFlow/Keras.

| Project | Task | Architecture |
|---|---|---|
| [`alzheimer-mri-classifier`](alzheimer-mri-classifier) | Multiclass MRI classification | CNN |
| [`digits-classifier`](digits-classifier) | Handwritten digit classification | CNN |
| [`rnn-text-prediction`](rnn-text-prediction) | Next-character / next-word prediction | SimpleRNN |
| [`lstm-concepts`](lstm-concepts) | LSTM architecture reference | LSTM (various) |
| [`lstm-temperature-forecast`](lstm-temperature-forecast) | Time-series forecasting | LSTM (various) |

Each project folder has its own `README.md` with dataset and usage details.

## Setup

```bash
git clone <your-repo-url>
cd deep-learning-projects
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Notes

- Datasets are **not** included in this repo — each project README explains
  what to download and where to place it.
- Notebooks save trained models locally (`.h5` / `.keras` files); these are
  git-ignored.
