# NYC Temperature Forecasting with LSTM

Forecasts daily average temperature from historical NYC weather data. Trains
and compares four LSTM variants (basic, stacked, bidirectional, dropout-
regularized) on the same train/test split, picks the best by RMSE, and
produces a next-day forecast. Also includes an encoder–decoder (seq2seq)
architecture as a reference for multi-step forecasting.

## Dataset

Not included in this repo. Place `nyc_temperature.csv` (with `date` and `tavg`
columns) in a `dataset/` folder next to the notebook:

```
lstm-temperature-forecast/
├── lstm_temperature_forecast.ipynb
└── dataset/
    └── nyc_temperature.csv
```

## Usage

```bash
pip install -r ../requirements.txt
jupyter notebook lstm_temperature_forecast.ipynb
```
