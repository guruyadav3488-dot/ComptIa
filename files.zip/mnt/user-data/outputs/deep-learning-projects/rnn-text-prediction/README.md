# Simple RNN Text Prediction

Three small `SimpleRNN` experiments on a tiny hand-written text corpus:

1. **Character-level** next-character prediction
2. **Word-level** next-word prediction
3. **Bonus:** a reverse "previous word" predictor using an `Embedding` layer

No external dataset needed — the corpus is defined inline in the notebook.

## Usage

```bash
pip install -r ../requirements.txt
jupyter notebook rnn_text_prediction.ipynb
```
