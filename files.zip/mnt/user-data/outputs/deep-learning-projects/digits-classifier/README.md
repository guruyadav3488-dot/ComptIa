# Handwritten Digit Classification — CNN

A small CNN trained on scikit-learn's built-in `digits` dataset (8×8 grayscale
images, digits 0–9). No external dataset needed — everything loads from
`sklearn.datasets`.

## Model

Two Conv2D blocks followed by a dense head, ~94% test accuracy after 10 epochs.

## Usage

```bash
pip install -r ../requirements.txt
jupyter notebook digits_cnn.ipynb
```
