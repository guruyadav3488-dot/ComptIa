# Alzheimer's MRI Classification — CNN

A convolutional neural network that classifies brain MRI scans into four stages
of Alzheimer's disease progression.

## Dataset

Not included in this repo. Expected layout — one subfolder per class:

```
data/
├── Non_Demented/
├── Very_Mild_Demented/
├── Mild_Demented/
└── Moderate_Demented/
```

Update the `DATA_DIR` variable in the notebook to point at your local copy.

## Model

A 3-block CNN (Conv2D + MaxPooling ×3) followed by a dense classification head,
trained with `categorical_crossentropy` for 10 epochs.

## Usage

```bash
pip install -r ../requirements.txt
jupyter notebook alzheimer_multiclass_cnn.ipynb
```
