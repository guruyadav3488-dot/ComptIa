# LSTM Architecture Reference

A quick tour of common LSTM architectures in Keras — vanilla, stacked,
bidirectional, multivariate, `return_sequences`, `Embedding`-based text models,
and an encoder–decoder (seq2seq) pattern. Each is defined and compiled (some
lightly trained on toy data) so you can inspect `model.summary()` and use any
block as a starting point for your own project.

## Usage

```bash
pip install -r ../requirements.txt
jupyter notebook lstm_architectures.ipynb
```
